import logo from './logo.svg';
import './App.css';
import { useSelector } from 'react-redux';
import Home from './Home';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AddProduct from './AddProduct';
import EditProduct from './EditProduct';



function App() {




  return (
    <div className="App">
      <h1>Redux Example </h1>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home></Home>}></Route>
          <Route path='/add' element={<AddProduct></AddProduct>}></Route>
          <Route path='/edit/:id' element={<EditProduct></EditProduct>}></Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
