export  const Users = [
    {"id":1,"name":"Key","Price":"120rs"},
    {"id":2,"name":"Cap","Price":"180rs"},
    {"id":3,"name":"Kite","Price":"20rs"}
]