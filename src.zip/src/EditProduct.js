import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { editProduct } from './reducer'

function EditProduct() {

    const product = useSelector(state => state.productData)
    const { id } = useParams()

    const prd_id = product.filter((prd) => {
        return prd.id == id
    })
    




    const {name,Price} = prd_id[0]

    const [uname, setuName] = useState(name)

    const [uPrice, setuPrice] = useState(Price)

    const dispatch = useDispatch()
    
    const handleedit = (e) => {
        e.preventDefault()
        dispatch(editProduct({ id: id, uname, uPrice }))
    }

    return (
        <>
            <h1>Go Back Home</h1>
            <Link to={'/'} className='btn btn-info'>Home</Link>

            <h1>Add Product</h1>

            <div className='container-fluid'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6 text-start'>
                        <form onSubmit={handleedit}>
                            <div className="mb-3">
                                <label className="form-label">Name : </label>
                                <input type="text" value={uname} onChange={(e) => { setuName(e.target.value) }} className="form-control" id="exampleInputEmail1" />

                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label">Price :</label>
                                <input type="text" value={uPrice} onChange={(e) => { setuPrice(e.target.value) }} className="form-control" id="exampleInputPassword1" />
                            </div>

                            <button type="submit" className="btn btn-primary">Edit Product</button>
                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}

export default EditProduct













