import { createSlice } from "@reduxjs/toolkit";
import { Users } from "./data";



const userSlice = createSlice({
        name:"Users",
        initialState: Users,
        reducers:{
            addProduct:(state,action)=>{
                //   console.log(state)
                //   console.log(action.payload)


                  state.push(action.payload)
            },
            editProduct:(state,action)=>{

                //  console.log(state)
                 console.log(action.payload)  

                 const {id,uname,uPrice} = action.payload

                const product = state.find((product)=>{
                      
                   return product.id == id
                 })

                 if(product)
                 {
                    product.name = uname;
                    product.Price = uPrice;
                 }
            },
            deleteproduct:(state,action)=>{
                  console.log(action.payload)


                  const {id} = action.payload

                  const product = state.find((prd)=>{
                      return prd.id == id
                  })

                  if(product)
                  {
                    return state.filter(product => product.id !== id)
                  }
            }
        }
})

export const {addProduct , editProduct,deleteproduct} = userSlice.actions
export default userSlice.reducer;
