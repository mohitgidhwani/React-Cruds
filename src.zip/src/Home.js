import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { deleteproduct } from './reducer'

function Home() {
    const product = useSelector((state) => (state.productData))


    const dispatch = useDispatch()
    
    const handledelete = (id)=>{
           dispatch(deleteproduct({id}))
        
    }

  
    return (
        <>
        <h2>Add Product</h2>
        <Link to={'/add'} className='btn btn-info'>Add</Link>
            <h2>Produc Data</h2>

            <div className='container-fluid'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6'>
                        <table className='table'>
                            <thead className='table-dark'>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {product.map((data) => (
                                    <tr key={data.id}>
                                        <td>{data.id}</td>
                                        <td>{data.name}</td>
                                        <td>{data.Price}</td>
                                        <td>
                                            <Link to={`/edit/${data.id}`} className='btn btn-danger mx-2'>Edit</Link>
                                            <button onClick={()=>{handledelete(data.id)}} className='btn btn-success '>Delete</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>


    )
}

export default Home